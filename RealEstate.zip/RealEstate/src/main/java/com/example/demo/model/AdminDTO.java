package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminDTO {
	private int aId;
	private String aName;
	private String aEmail;
	private String aPassword;

}
