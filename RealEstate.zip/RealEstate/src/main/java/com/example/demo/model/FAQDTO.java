package com.example.demo.model;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FAQDTO {
	private int eId;
	private String eName;
	private long eMobNo;
	private String eMsg;
	

}
