package com.example.demo.model;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PropertiesDTO {
	private int pId;
	private String pName;
	private String pType;
	private String pAddress;
	private String pImage;
	private String pDesc;

}
