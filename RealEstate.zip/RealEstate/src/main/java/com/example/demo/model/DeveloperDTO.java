package com.example.demo.model;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class DeveloperDTO {

	private int dId;
	private String dName;
	private long dContact;
	private String dEmail;
	private String dPassword;
	private String dCity;
}
